<?php
define ("LIB_DIR", __DIR__ . "/../libs/");
define ("TEMPLATE_DIR", __DIR__ . "/../templates/");
define ("PUBLIC_IMG_DIR_URL", "img/");
define ("PUBLIC_THUMB_DIR_URL", "thumb/");
define ("IMG_DIR", __DIR__ . "/../public/" . PUBLIC_IMG_DIR_URL);
define ("THUMB_DIR", __DIR__ . "/../public/" . PUBLIC_THUMB_DIR_URL);
